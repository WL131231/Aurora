# aiohttp Android stub (no-op)
