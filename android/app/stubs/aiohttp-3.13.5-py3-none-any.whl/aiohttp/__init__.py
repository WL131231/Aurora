# aiohttp Android stub — WSMsgType + 최소 no-op 구현
# Why: python-telegram-bot 이 aiohttp.WSMsgType 을 import.
#      Chaquopy ARM64 wheel 없어 C 확장 빌드 불가 → 더미로 의존성 해결.
from enum import IntEnum


class WSMsgType(IntEnum):
    """WebSocket 메시지 타입 — python-telegram-bot BotInstance 경고 해소용."""
    CONTINUATION = 0x0
    TEXT = 0x1
    BINARY = 0x2
    CLOSE = 0x8
    PING = 0x9
    PONG = 0xA
    CLOSING = 256
    CLOSED = 257
    ERROR = 258
