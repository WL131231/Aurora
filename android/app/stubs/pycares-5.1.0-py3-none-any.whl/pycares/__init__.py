# pycares Android stub (no-op)
