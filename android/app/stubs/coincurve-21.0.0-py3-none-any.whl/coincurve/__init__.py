# coincurve Android stub (no-op)
